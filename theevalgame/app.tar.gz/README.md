# the eval game

https://oskaerik.github.io/theevalgame/
